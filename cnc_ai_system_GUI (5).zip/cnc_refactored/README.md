# cnc_ai_system
CNC Trade with AI
